import org.example.Calculator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class CalculatorTest {

    private Calculator calculator;

    @BeforeEach
    public void setUp() {
        calculator = new Calculator();
    }

    @Test
    public void addTest() {
        int a = 5;
        int b = 10;
        int expected = 15;
        int result = calculator.add(a, b);
        assertEquals(expected, result, "5 + 10 should equal 15");
    }

    @Test
    public void subtractTest() {
        int a = 20;
        int b = 5;
        int expected = 15;
        int result = calculator.subtract(a, b);
        assertEquals(expected, result, "20 - 5 should equal 15");
    }

    @Test
    public void multiplyTest() {
        int a = 4;
        int b = 5;
        int expected = 20;
        int result = calculator.multiply(a, b);
        assertEquals(expected, result, "4 * 5 should equal 20");
    }

    @Test
    public void divideTest() {
        int a = 15;
        int b = 3;
        int expected = 5;
        int result = calculator.divide(a, b);
        assertEquals(expected, result, "15 / 3 should equal 5");
    }

    @Test
    public void divideByZeroTest() {
        int a = 10;
        int b = 0;
        assertThrows(IllegalArgumentException.class, () -> calculator.divide(a, b), "Cannot divide by zero");
    }
}